<!DOCTYPE html>
<html>
<head>
<title>Book details</title>
</head>
<body>

<form method="post">
    <label>leave a review!</label><br>
    <label>login</label>
    <input type="text" name="login" value=""><br>
    <label>password</label>
    <input type="password" name="password" value=""><br>
    <label>review</label>
    <input type="text" name="review" value=""><br>
    <label>stars</label>
    <input type="number" name="star" min="1" max="5" value=""><br>
    <input type="submit" name="submit" value="Submit">
</form>

<?php
$hostname = "localhost";
$username = "root";
$dbpassword = "";
$dbname = "books_db";

$con = mysqli_connect($hostname, $username, $dbpassword, $dbname);
if (!$con) {
    die("uh oh, something went wrong : (" . mysqli_connect_error());
}

if (isset($_GET['book_id'])) {
    $book_id = mysqli_real_escape_string($con, $_GET['book_id']);
    $sql = "SELECT * FROM books_dt WHERE book_id='$book_id'";
    $result = mysqli_query($con, $sql);
    if ($row = mysqli_fetch_assoc($result)) {
        $name = htmlspecialchars($row['name']);
        $author = htmlspecialchars($row['author']);
        $genre = htmlspecialchars($row['genre']);
        echo "<h1>$name</h1>";
        echo "$author <br>$genre <br><br><br>Reviews";     

        $sql = "SELECT * FROM reviews_dt WHERE book_id='$book_id'";
        $result = mysqli_query($con, $sql);
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $login = htmlspecialchars($row['login']);
                $star = htmlspecialchars($row['star']);
                $review = htmlspecialchars($row['review']);
                echo "<br>$login rated this book as $star-star worthy<br>$review <br><br><br><br><br>";
            }
        } else {
            echo "<br>no reviews yet";
        }
    } else {
        echo "book not found";
    }
}

if (isset($_POST['submit'])) {
    $user_login = mysqli_real_escape_string($con, $_POST['login']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    $sql = "SELECT * FROM users_dt WHERE login='$user_login' AND password='$password'";
    $result = mysqli_query($con, $sql);

    if (mysqli_num_rows($result) === 1) {
        $review = mysqli_real_escape_string($con, $_POST['review']);
        $star = intval($_POST['star']);
        $query = "INSERT INTO reviews_dt (login, book_id, star, review) VALUES ('$user_login', '$book_id', '$star', '$review')";
        if (mysqli_query($con, $query)) {
            echo "<br> yay";
        } else {
            echo "oopsie! error occurred " . mysqli_error($con);
        }
    } else {
        echo "user not found 0_o";
    }
}

mysqli_close($con);
?>

</body>
</html>