<!DOCTYPE html>
<html>
<head>
    <title>Book Recommendations</title>
</head>
<body>
    <h1>personal book recs</h1>
    <form method="post">
        <label>login:</label>
        <input type="text" name="login" required>
        <input type="submit" name="submit" value="Get Recommendations">
    </form>

    <?php
    // Database connection parameters
    $hostname = "localhost";
    $username = "root";
    $password = ""; // Put your database password here
    $dbname = "books_db";

    // Connect to the database
    $con = mysqli_connect($hostname, $username, $password, $dbname);
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    if (isset($_POST['submit'])) {
        $login = $_POST['login'];

        // all ratings fetched
        $ratings_query = "SELECT * FROM reviews_dt";
        $ratings_result = mysqli_query($con, $ratings_query);

        //store in  a dicitionary
        $ratings = array();
        while ($row = mysqli_fetch_assoc($ratings_result)) {
            $ratings[$row['login']][$row['book_id']] = $row['star'];
        }

        //user whos elogin is entered ratings
        $user_ratings = isset($ratings[$login]) ? $ratings[$login] : array();

        //similarity scores calculatION
        $similarity_scores = array();
        foreach ($ratings as $other_login => $other_ratings) {
            if ($other_login !== $login) {
                $similarity_score = 0;
                $common_books = array_intersect_key($user_ratings, $other_ratings);
                foreach ($common_books as $book_id => $user_rating) {
                    $similarity_score += abs($user_rating - $other_ratings[$book_id]);
                }
                $similarity_scores[$other_login] = $similarity_score;
            }
        }

        asort($similarity_scores);

        $most_similar_user = key($similarity_scores);

        $recommendations_query = "SELECT b.name, b.author, b.genre
                                  FROM books_dt b
                                  INNER JOIN reviews_dt r ON b.book_id = r.book_id
                                  WHERE r.login = '$most_similar_user' AND r.book_id NOT IN (SELECT book_id FROM reviews_dt WHERE login = '$login')
                                  LIMIT 5"; 
        $recommendations_result = mysqli_query($con, $recommendations_query); //top 5 only

        if (mysqli_num_rows($recommendations_result) > 0) {
            echo "<h2>i think youll enjoy these</h2>";
            echo "<ul>";
            while ($row = mysqli_fetch_assoc($recommendations_result)) {
                echo "<li>{$row['name']} by {$row['author']} in {$row['genre']}</li>";
            }
            echo "</ul>";
        } else {
            echo "<p>no recs for you sadly : (</p>";
        }
    }

    mysqli_close($con);
    ?>
</body>
</html>