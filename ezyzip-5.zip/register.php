<!DOCTYPE html>
<html>
<head>
    <title>Registration form!</title>
</head>
<body>
    <div class="header">
        <h1>Register</h2>
    </div>

<form method="post">
    <label>Login</label>
    <input type="text" name="login" value=""></br>
    <label>Password</label>
    <input type="text" name="password" value=""></br>
    <input type="submit" name="submit" value="submit">
</form>

<?php
if (isset ($_POST['submit'])){
    $login=$_POST['login'];
    $password=$_POST['password'];
    $mysqli = new mysqli("localhost","root", "", "books_db");
    if($mysqli->connect_errno){
        echo "uh oh, error on website";
        exit;
    }
    $login_format='"'.$mysqli->real_escape_string($login).'"';
    $password_format='"'.$mysqli->real_escape_string($password).'"';
    $query="INSERT INTO users_dt(login, password) VALUES ($login_format, $password_format)";
    $result=$mysqli->query ($query);
    if ($result){
        echo "yay";
    }
// close connection
mysqli_close($mysqli);
}
?>

</body>
</html>
