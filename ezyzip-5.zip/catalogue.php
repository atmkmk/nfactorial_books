<!DOCTYPE html>
<html>
<head>
<title>Books</title>
</head>
<body>
<h1>Book catalogue</h1>
<br>
<form method="post">
    <input type="text" name="question" placeholder="your search query goes here...">
    <input type='submit' name='submit'>
    <br>
</form>
<?php
    $query_performed=0;
    //storing database details in variables.
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $dbname = "books_db";

    //creating connection to database
    $con = mysqli_connect($hostname, $username, $password, $dbname);
    //checking if connection is working or not
    if(!$con)
    {
        die("uh oh something went wrong" . mysqli_connect_error());
    }
    else 
    {
        echo "connection successful : D <br>";
    }
    $sql = "SELECT name, author, genre, book_id FROM books_dt order by name";
    //fire query
    $result = mysqli_query($con, $sql);
    if(mysqli_num_rows($result) && $query_performed=0)
    {
        while($row = mysqli_fetch_assoc($result)){
		$name=$row['name'];
    	$author=$row['author'];
    	$genre=$row['genre'];
        $book_id=$row['book_id'];
        // using while to have many dynamic data displayed on screen 
		echo "
			<a href='book_details.php?book_id=$book_id''>$name</a> <br> 
            $author<br>
            $genre <br><br><br><br>";       
		}
    }
    else
    {
        echo "0 results";
    }

    if (isset($_POST['submit'])) {
        $query_performed=1;
        echo "submitted";
        $question = mysqli_real_escape_string($con, $_POST['question']);
        $sql = "SELECT * FROM books_dt WHERE name='$question' OR genre='$question' OR author='$question'";
        $result = mysqli_query($con, $sql);
        if(mysqli_num_rows($result))
        {
            while($row = mysqli_fetch_assoc($result)){
            $name=$row['name'];
            $author=$row['author'];
            $genre=$row['genre'];
            $book_id=$row['book_id'];
            // using while to have many dynamic data displayed on screen 
            echo "
                <a href='book_details.php?book_id=$book_id''>$name</a> <br> 
                $author<br>
                $genre <br><br><br><br>";       
            }
        }
        else
        {
            echo "0 results";
        }
        
    }

    // closing connection
    mysqli_close($con);
?>
</body>
</html>